set(rosserial_arduino_MESSAGE_FILES "/home/hyojin/catkin_ws/src/rosserial/rosserial_arduino/msg/Adc.msg")
set(rosserial_arduino_SERVICE_FILES "/home/hyojin/catkin_ws/src/rosserial/rosserial_arduino/srv/Test.srv")
