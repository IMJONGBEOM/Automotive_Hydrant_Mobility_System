(cl:in-package pmod_msgs-msg)
(cl:export '(LEFT-VAL
          LEFT
          RIGHT-VAL
          RIGHT
))