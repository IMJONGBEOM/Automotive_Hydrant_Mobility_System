(cl:in-package pmod_msgs-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
          THETA-VAL
          THETA
))