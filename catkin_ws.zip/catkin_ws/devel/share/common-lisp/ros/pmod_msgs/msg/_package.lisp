(cl:defpackage pmod_msgs-msg
  (:use )
  (:export
   "<MOTOR>"
   "MOTOR"
   "<POSITION>"
   "POSITION"
  ))

