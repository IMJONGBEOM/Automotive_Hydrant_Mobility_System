set(rosserial_msgs_MESSAGE_FILES "/home/hyojin/catkin_ws/src/rosserial/rosserial_msgs/msg/Log.msg;/home/hyojin/catkin_ws/src/rosserial/rosserial_msgs/msg/TopicInfo.msg")
set(rosserial_msgs_SERVICE_FILES "/home/hyojin/catkin_ws/src/rosserial/rosserial_msgs/srv/RequestParam.srv")
