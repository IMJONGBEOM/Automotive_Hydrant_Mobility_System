# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(pmod_msgs_MSG_INCLUDE_DIRS "/home/hyojin/catkin_ws/src/pmod_msgs/msg")
set(pmod_msgs_MSG_DEPENDENCIES std_msgs)
