set(pmod_msgs_MESSAGE_FILES "/home/hyojin/catkin_ws/src/pmod_msgs/msg/Position.msg;/home/hyojin/catkin_ws/src/pmod_msgs/msg/Motor.msg")
set(pmod_msgs_SERVICE_FILES "")
